//import logo from './logo.svg';
import './App.css';
import TestApi from "./component/check/test-api.jsx";
import Test from "./component/test";

function App() {
  return (
    <div>
      <Test/>
    </div>  
  );
}

export default App;
